-- Buckets
-- Create a storage bucket named "audio" (idempotent)
select storage.create_bucket('audio', public => true)
where not exists (
  select 1 from storage.buckets where id = 'audio'
);

-- Ensure public read access to objects in the 'audio' bucket (idempotent)
-- Allow anyone to read files in the "audio" bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Public read for audio bucket'
  ) THEN
    CREATE POLICY "Public read for audio bucket"
      ON storage.objects
      FOR SELECT
      USING (
        bucket_id = 'audio'
      );
  END IF;
END $$;

-- Allow authenticated users to insert into the "audio" bucket
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Authenticated insert for audio bucket'
  ) THEN
    CREATE POLICY "Authenticated insert for audio bucket"
      ON storage.objects
      FOR INSERT
      WITH CHECK (
        bucket_id = 'audio'
      );
  END IF;
END $$;

-- Allow owners to update/delete their own objects (optional; adjust as needed)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Owner update for audio bucket'
  ) THEN
    CREATE POLICY "Owner update for audio bucket"
      ON storage.objects
      FOR UPDATE
      USING (
        bucket_id = 'audio' AND auth.uid() = owner
      );
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Owner delete for audio bucket'
  ) THEN
    CREATE POLICY "Owner delete for audio bucket"
      ON storage.objects
      FOR DELETE
      USING (
        bucket_id = 'audio' AND auth.uid() = owner
      );
  END IF;
END $$;

-- Note: No need to pre-create the prefix "uploads/". Folders are virtual; just upload to
-- path 'uploads/<file>' and it will appear in the UI.

-- Tables
create table if not exists public.emotion_scores (
  id bigserial primary key,
  session_id uuid not null,
  role text not null check (role in ('user','sophia')),
  label text not null check (label in ('neutral','positive','negative')),
  confidence double precision not null,
  timestamp bigint not null
);

create table if not exists public.conversation_sessions (
  id uuid primary key,
  timestamp timestamp with time zone default now(),
  audio_url text,
  response_audio_url text,
  transcript text,
  response text,
  latency double precision,
  user_id text,
  user_emotion jsonb,
  sophia_emotion jsonb,
  source text default 'chat-web',
  created_at bigint
);
