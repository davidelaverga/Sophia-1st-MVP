import base64
import io
import time
import uuid
import logging
from typing import Optional

from fastapi import FastAPI, File, UploadFile, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from app.config import get_settings
from app.deps import verify_api_key, limiter
from app.services.mistral import transcribe_audio_with_voxtral, generate_llm_reply
from app.services.emotion import analyze_emotion_text, analyze_emotion_audio
from app.services.tts import synthesize_inworld
from app.services.supabase import (
    get_supabase,
    upload_audio_and_get_url,
    insert_emotion_score,
    insert_conversation_session,
    supabase
)
#load env file
from dotenv import load_dotenv
load_dotenv(r"C:\Users\ajdee\Sophia-1st-MVP (2)\Sophia-1st-MVP\.env")

settings = get_settings()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("sophia-backend")

app = FastAPI(title=settings.APP_NAME)

# CORS (adjust as needed)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Rate limiter integration
app.state.limiter = limiter
from slowapi.errors import RateLimitExceeded
from slowapi import _rate_limit_exceeded_handler
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


# ----- Models -----
class Emotion(BaseModel):
    label: str
    confidence: float

class TranscriptionResponse(BaseModel):
    text: str
    emotion: Emotion

class GenerateResponse(BaseModel):
    reply: str
    tone: Optional[str] = "neutral"

class SynthesizeResponse(BaseModel):
    audio_url: str
    emotion: Emotion

class ChatResponse(BaseModel):
    transcript: str
    reply: str
    user_emotion: Emotion
    sophia_emotion: Emotion
    audio_url: str


@app.get("/")
def root():
    return {"message": "Sophia AI Backend is running."}


@app.post("/transcribe", response_model=TranscriptionResponse)
@limiter.limit(settings.API_RATE_LIMIT)
async def transcribe(
    request: Request,
    file: UploadFile = File(...),
    api_key_ok: None = Depends(verify_api_key),
):
    if not file.filename.lower().endswith(".wav"):
        raise HTTPException(status_code=400, detail="File must be a WAV audio file.")

    session_id = uuid.uuid4()

    try:
        wav_bytes = await file.read()
        text = transcribe_audio_with_voxtral(wav_bytes)
    except Exception as e:
        logger.exception("Transcription failed")
        raise HTTPException(status_code=500, detail="Transcription failed")

    # Emotion from audio using Phoenix + Gemini (audio-based)
    user_emotion = analyze_emotion_audio(wav_bytes)

    # Skip emotion score persistence in /transcribe endpoint
    # The foreign key constraint requires conversation_sessions to exist first

    return TranscriptionResponse(text=text, emotion=user_emotion.model_dump())


class GenerateRequest(BaseModel):
    text: str

@app.post("/generate-response", response_model=GenerateResponse)
@limiter.limit(settings.API_RATE_LIMIT)
async def generate_response(
    request: Request,
    body: GenerateRequest,
    api_key_ok: None = Depends(verify_api_key),
):
    try:
        reply = generate_llm_reply(body.text)
    except Exception:
        logger.exception("LLM response generation failed")
        raise HTTPException(status_code=500, detail="Response generation failed")

    return GenerateResponse(reply=reply, tone="encouraging")


class SynthesizeRequest(BaseModel):
    text: str

@app.post("/synthesize", response_model=SynthesizeResponse)
@limiter.limit(settings.API_RATE_LIMIT)
async def synthesize(
    request: Request,
    body: SynthesizeRequest,
    api_key_ok: None = Depends(verify_api_key),
):
    # TTS
    try:
        audio_bytes = synthesize_inworld(body.text)
    except Exception:
        logger.exception("TTS synthesis failed")
        raise HTTPException(status_code=500, detail="Synthesis failed")

    # Upload to storage and get URL
    try:
        file_name = f"sophia_{int(time.time()*1000)}.mp3"
        audio_url = upload_audio_and_get_url(file_bytes=audio_bytes, file_name=file_name)
    except Exception:
        logger.exception("Audio upload failed")
        raise HTTPException(status_code=500, detail="Audio upload failed")

    # Emotion from synthesized audio (audio-based)
    sophia_emotion = analyze_emotion_audio(audio_bytes)

    # Skip emotion score persistence in /synthesize endpoint
    # The foreign key constraint requires conversation_sessions to exist first

    return SynthesizeResponse(audio_url=audio_url, emotion=sophia_emotion.model_dump())


@app.post("/chat", response_model=ChatResponse)
@limiter.limit(settings.API_RATE_LIMIT)
async def chat(
    request: Request,
    file: UploadFile = File(...),
    api_key_ok: None = Depends(verify_api_key),
):
    if not file.filename.lower().endswith(".wav"):
        raise HTTPException(status_code=400, detail="File must be a WAV audio file.")

    # Generate a unique session ID for each conversation
    session_id = uuid.uuid4()
    logger.info(f"Generated new session ID: {session_id}")

    try:
        wav_bytes = await file.read()
        transcript = transcribe_audio_with_voxtral(wav_bytes)
    except Exception:
        logger.exception("Transcription failed in chat")
        raise HTTPException(status_code=500, detail="Transcription failed")

    # Audio-based emotion for user's input audio
    user_emotion = analyze_emotion_audio(wav_bytes)

    try:
        reply = generate_llm_reply(transcript)
    except Exception:
        logger.exception("LLM generation failed in chat")
        raise HTTPException(status_code=500, detail="Response generation failed")

    try:
        audio_bytes = synthesize_inworld(reply)
        file_name = f"sophia_{int(time.time()*1000)}.mp3"
        audio_url = upload_audio_and_get_url(file_bytes=audio_bytes, file_name=file_name)
    except Exception:
        logger.exception("Synthesis or upload failed in chat")
        raise HTTPException(status_code=500, detail="Synthesis failed")

    # Audio-based emotion for Sophia's synthesized audio
    sophia_emotion = analyze_emotion_audio(audio_bytes)
    
    # Ensure emotion labels match the database constraints
    # Map any non-standard labels to allowed values
    allowed_labels = ["positive", "neutral", "negative"]
    
    user_emotion_label = user_emotion.label
    if user_emotion_label not in allowed_labels:
        user_emotion_label = "neutral"
        
    sophia_emotion_label = sophia_emotion.label
    if sophia_emotion_label not in allowed_labels:
        sophia_emotion_label = "neutral"

    # Persist full session first (required by foreign key constraint)
    try:
        # Always use the test user ID for all operations
        test_user_id = "00000000-0000-0000-0000-000000000000"  # Hardcoded test user ID
        logger.info(f"Using test user ID: {test_user_id} for all operations")
        
        # Insert conversation session with the test user ID
        insert_conversation_session({
            "id": str(session_id),
            "transcript": transcript,
            "reply": reply,
            "user_emotion_label": user_emotion_label,
            "user_emotion_confidence": user_emotion.confidence,
            "sophia_emotion_label": sophia_emotion_label,
            "sophia_emotion_confidence": sophia_emotion.confidence,
            "audio_url": audio_url,
            "user_id": test_user_id,  # Always use test user ID
        })
        
        # Now that the conversation session exists, we can insert emotion scores
        insert_emotion_score(str(session_id), role="user", emotion=user_emotion, user_id=test_user_id)
        insert_emotion_score(str(session_id), role="sophia", emotion=sophia_emotion, user_id=test_user_id)
    
        
        # Handle any other database errors
    except Exception as e:
        logger.warning(f"Persist conversation data failed: {e}; continuing")

    return ChatResponse(
        transcript=transcript,
        reply=reply,
        user_emotion=user_emotion.model_dump(),
        sophia_emotion=sophia_emotion.model_dump(),
        audio_url=audio_url,
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",   # points to the FastAPI instance (`app`) inside this file
        host="0.0.0.0", 
        port=8000, 
        reload=True   # reloads on file changes (good for dev, remove in prod)
    )